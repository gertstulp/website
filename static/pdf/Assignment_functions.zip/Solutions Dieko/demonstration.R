# Demonstration of variable plotting functions

# Load the tidyverse
library(tidyverse)

# Load the functions
source("functions.R")

# Select the dataset
mpg = ggplot2::mpg

# Try plotting a continuous variable
PlotVariable(mpg$hwy)

# Try plotting a categorical variable
PlotVariable(mpg$class)

# Add fill to the continous variable plot (e.g. by manufacturer)
## The non-tidyverse way
plot = PlotVariable(mpg$hwy)
AddColor(plot, mpg$manufacturer)
## The tidyverse way
PlotVariable(mpg$hwy) %>%
  AddColor(mpg$manufacturer)

# Add fill to the categorical plot
PlotVariable(mpg$class) %>%
  AddColor(mpg$manufacturer)