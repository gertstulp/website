### Define functions to plot data

PlotVariable = function(variable) {
  # Create a plot for the variable entered as a parameter
  # Select between density plots for continuous variables
  # and bar charts for categorical variables
  
  plot.type = switch(class(variable),  # determine the type of plot based on the class of variable
                         numeric = ,  # empty assignment in a switch statement means: same as the next. so numeric, integer and complex variables are all plotted with density plots
                         integer = ,
                         complex = "density",
                         character = ,
                         logical = ,
                         factor = "bar",
                         NULL  # the default is null: other variable classes can't be plotted with this function and will raise an error
                         )
  if (is.null(plot.type)) {stop(paste("The variable class ", class(variable), " cannot be plotted.", sep = ""))}  # raise error if plot type is NULL
  
  # Creating the plot for continuous variables
  if (plot.type == "density") {
    if (require('ggplot2')) {  # prefer using ggplot, but if the user doesn't have that installed try the base plot
      plot = ggplot() + geom_density(mapping = aes(x = variable)) 
    }
    else {
      warning("Package ggplot2 not installed, defaulting to base R plots")
      plot = plot(density(variable))
    }
  }
  # Creating the plot for categorical variables
  else if (plot.type == "bar") {
    if (require('ggplot2')) {
      plot = ggplot() + geom_bar(mapping = aes(x = variable)) 
    }
    else {
      warning("Package ggplot2 not installed, defaulting to base R plots")
      plot = barplot(table(variable))
    }
  }
  
  return(plot)  # this returns (if assigned to a variable) or renders the plot
}


AddColor = function(plot, color.by, fill = TRUE) {
  # Add color to an existing plot
  # Select between adding fill and (outline) color by setting the
  # 'fill' parameter to TRUE (fill) or FALSE (color)
  
  # By default, ggplot apparently looks in the global environment for its variables
  # We will work with that for the moment
  assign("color.by", color.by, envir = globalenv())
  if (fill) {
    plot.color = plot + aes(fill = color.by)
  }
  else {
    plot.color = plot + aes(color = color.by)
  }
  
  return(plot.color)
}