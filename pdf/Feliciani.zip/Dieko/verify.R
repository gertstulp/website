# Verify that the split datafiles can be recombined to the original datasets
library(tidyverse)

load("finalOutcomes.Rdata")
load("runParameters.Rdata")
load("runSteps.Rdata")

load("endSteps.Rdata")
load("completeRuns.Rdata")

# Check that ID is a primary key in the finalOutcomes and runParameters files
finalOutcomes %>% count(ID) %>% filter(n > 1)  # Is empty, so ID is a primary key (no ID occurs more than once)
runParameters %>% count(ID) %>% filter(n > 1)  # Is empty, so ID is a primary key (no ID occurs more than once)

# Check that ID combined with ticks forms a primary key in the runSteps file
runSteps %>% count(ID, ticks) %>% filter(n > 1)  # Is empty, so ID + ticks is a primary key (no combination of ID and ticks occurs more than once)

# Reform the endSteps dataset by combining finalOutcomes, runParameters and runSteps
endStepsReconstructed = left_join(finalOutcomes, runParameters, by = "ID")
endStepsReconstructed = left_join(endStepsReconstructed, runSteps, by = c("ID", "ticks"))

# Check that the original and reconstructed endSteps dataset are the same (intersect compares on all variables)
nrow(intersect(endSteps, endStepsReconstructed))  # All 3000 observations occur in both datasets, so they are identical

# Reform the completeRuns dataset by combining finalOutcomes, runParameters and runSteps
completeRunsReconstructed = left_join(runSteps, runParameters, by = "ID")
completeRunsReconstructed = left_join(completeRunsReconstructed, finalOutcomes, by = c("ID", "ticks"))

# Check that the original and reconstructed endSteps dataset are the same (intersect compares on all variables)
nrow(intersect(completeRuns, completeRunsReconstructed))  # Only 3000 out of 145725 observations occur in both datasets, so they are not identical
# Why? Because we only stored the final outcomes for the last step of each run. After all, there was no variation in any steps before then
# So this is not a problem, but we can confirm that anyway by doing the following:
completeRunsReconstructed$converged[is.na(completeRunsReconstructed$converged)] = "Not converged"
completeRunsReconstructed$outcome[is.na(completeRunsReconstructed$outcome)] = "Not converged"
completeRunsReconstructed$finished[is.na(completeRunsReconstructed$finished)] = 0
nrow(intersect(completeRuns, completeRunsReconstructed))  # Now all 145725 rows occur in both datasets, so they are identical
