library(tidyverse)

####
#Fixed at start
#ID
#population_size
#congruency_w
#initial_polarization
#Mechanism
#exchange
#homophily

#Varied throughout run
#ticks
#n_interactions
#finished
#mean_o_glob
#var_o_glob
#polarization_index
#count_extremists

#Only varied at end
#converged 
#outcome

# We will work only from the completeRuns data since I assume this is closest to how you get the data output from your simulation
# And we can reduce this to the endSteps data anyway
load('completeRuns.Rdata')

# Get all fixed run parameters + ID from completeRuns
runParameters = select(completeRuns, ID, population_size, congruency_w, initial_polarization, Mechanism, exchange, homophily)
runParameters = distinct(runParameters)  # Remove the many duplicate rows

# Get all final outcomes + nr of ticks + ID from completeRuns
finalOutcomes = filter(completeRuns, finished == 1)  # Select only last step of each run
finalOutcomes = select(finalOutcomes, ID, ticks, finished, converged, outcome)

# Select variables varied through run + ID
runSteps = select(completeRuns, ID, ticks, n_interactions, mean_o_glob, var_o_glob, polarization_index, count_extremists)

save(runParameters, file = "runParameters.Rdata")
save(finalOutcomes, file = "finalOutcomes.Rdata")
save(runSteps, file = "runSteps.Rdata")
