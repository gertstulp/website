library(foreign)

# Convert data from SPSS to Rdata
endSteps = read.spss("PA-endStepOnly.sav", to.data.frame = TRUE)
completeRuns = read.spss("PA-completeRuns.sav", to.data.frame = TRUE)

save(completeRuns, file = "completeRuns.Rdata")
save(endSteps, file = "endSteps.Rdata")