# Solution by Thomas Feliciani with minor additions of Robert Krause
#
# This script assumes that we have the data folder in the working directory or
# in the same folder as the script: "./networkAssignment/"

#rm(list = ls())
#install(readxl)
library(tidyverse)
library(readxl) # <- need this one as well!
library(haven)
library(network)


# __PART 1 _____________________________________________________________________

# We can load any of the input excel files:
nw <- as.data.frame(read_excel("./networkAssignment/nodelist_names1.xlsx"))
#nw <- as.data.frame(read_excel("./networkAssignment/nodelist_numbers2.xlsx"))

# We extract information on pupils' attributes in a crude way:
attributes <- nw[,c((ncol(nw) - 3):ncol(nw))]

# We replace all missing ties with a 0. We need this step so that later we can
# loop through our database without worrying about NA cells.
nw[is.na(nw)] <- 0

# Next, we make sure we use a way to identify pupils in a way that is consistent
# across the possible input networks. In our case, we transform every name into
# integers, following the order of appearance in the database.
names <- unique(nw$ID)
index <- 1
for (n in 1:length(names)){
  for (i in 1:nrow(nw)){
    for (j in 1:ncol(nw)){
      if (nw[i,j] == names[n]) {nw[i,j] <- index}
    }
  }
  index <- index + 1
}

# We remove all columns we don't need, in a way that we are left with a minimal
# nodelist:
nw <- nw[,2:16]

# Now we crete a matrix that we will fill with information from the nodelist:
adjM <- matrix(nrow=nrow(nw),ncol=nrow(nw))

# Finally, we read through the nodelist row by row and and fill in the adjacency
# matrix with the edges we find:
for (i in 1:nrow(nw)){
  for (j in 1:ncol(nw)){
    x <- as.integer(nw[i,j])
    #print(x)
    if (x != 0){
      adjM[i,x] <- 1
    }
  }
}

# And now we plot with the simplified function suggested by Robert:
plot.network.default(as.network(adjM))

# __PART 2 _____________________________________________________________________
# This part will create 1) a separete matrix for each class, named after the
# class, and 2) one list (net_list) that contains all these matrices, each
# element named after the class.


# We read in the SPSS data.
nw <- as.data.frame(read_sav("./networkAssignment/projectData.sav"))

# First, we need to create a list of existing classroom in the dataset. To do so,
# we create a vector of class names that are found in the dataset.
classes <- unique(nw$class)
head(classes)

net_list <- list()

# Next, we loop through every classroom in the list of classrooms:
for (cl in classes) {

  # For every classroom, we extract the relevant part of the dataset.
  classNw <- subset(nw, class == cl)

  # And then we order the pupils correctly:
  classNw <- arrange(classNw, as.integer(classNw$pupilNr))

  # Now the variable 'classNw' stores all the information concerning a classroom.
  # It's time to run a test. We check whether our classroom data is consistent.
  # Specifically, we check whether it has the right number of pupils, and if the
  # information about the number of pupils is consistent.
  if (nrow(classNw) != classNw$nPupils[1] |
      length(table(classNw$nPupils)) != 1
  ) {stop(paste(
    "Inconsistent information on the number of pupils. Classroom:",
    c
  ))}

  # Next, we trim off the useless part of the adjency matrix, which consists of
  # the last few columns of the matrix. How many useless columns we need to trim
  # off depends on the classroom size (variable nPupils):
  NumberUselessColumns <- ncol(classNw) - classNw$nPupils[1] - 6
  classNw <- classNw[,c(1:(ncol(classNw) - NumberUselessColumns))]

  # If we want, we can also remove the metadata (that is, the first few columns).
  # This leaves us with a bare adjacency matrix per classroom.
  classNw <- classNw[,c(-2, -3, -4, -5, -6)] # This command removes metadata
  classNw <- classNw[,-1]                    # This command also removes row IDs


  # Now we have stored in 'classNw' all the relevant information about a given
  # classroom. We can conclude by storing this information into a dataframe
  # whose name is the name of the classroom.
  assign(cl, classNw)
  net_list <- classNw
  names(net_list)[[length(net_list) + 1]] <- cl
}

